<?php

namespace App\Service;

use App\Repository\RatingRepository;

class RatingService
{
    private RatingRepository $repository;

    public function __construct(RatingRepository $repository)
    {
        $this->repository = $repository;
    }

    public function rateRecipe(int $recipeId, int $score): void
    {
        $score = max(1, min(5, $score)); // enforce 1-5 range
        $this->repository->addRating($recipeId, $score);
    }
}
