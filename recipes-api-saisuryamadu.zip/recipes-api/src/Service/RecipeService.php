<?php

namespace App\Service;

use App\Repository\RecipeRepository;

class RecipeService
{
    private RecipeRepository $repository;

    public function __construct(RecipeRepository $repository)
    {
        $this->repository = $repository;
    }

    public function listRecipes(): array
    {
        return $this->repository->getAll();
    }

    public function getRecipe(int $id): ?array
    {
        return $this->repository->getById($id);
    }

    public function createRecipe(array $data): array
    {
        return $this->repository->create($data);
    }

    public function updateRecipe(int $id, array $data): bool
    {
        return $this->repository->update($id, $data);
    }

    public function deleteRecipe(int $id): bool
    {
        return $this->repository->delete($id);
    }

    public function searchRecipes(string $query): array
    {
        return $this->repository->search($query);
    }
}
