<?php

namespace App\Service;

class CacheService
{
    private $redis;

    public function __construct()
    {
        $this->redis = new \Redis();
        $this->redis->connect('redis', 6379);
    }

    public function get(string $key)
    {
        return $this->redis->get($key);
    }

    public function set(string $key, string $value, int $ttl = 3600)
    {
        $this->redis->setex($key, $ttl, $value);
    }
}
