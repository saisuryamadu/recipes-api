<?php

namespace App\Middleware;

class AuthMiddleware
{
    public static function ensureAuthenticated(): void
    {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? null;

        if (!$token || $token !== 'Bearer secret-token') {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
    }
}
