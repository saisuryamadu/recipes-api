<?php

namespace App\Repository;

use PDO;

class RatingRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function addRating(int $recipeId, int $score): void
    {
        $stmt = $this->db->prepare('INSERT INTO ratings (recipe_id, score) VALUES (:recipe_id, :score)');
        $stmt->execute([
            'recipe_id' => $recipeId,
            'score' => $score
        ]);
    }
}
