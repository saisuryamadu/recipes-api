<?php

namespace App\Repository;

use PDO;

class RecipeRepository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function getAll(): array
    {
        $stmt = $this->db->query("SELECT * FROM recipes");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM recipes WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $recipe = $stmt->fetch(PDO::FETCH_ASSOC);
        return $recipe ?: null;
    }

    public function create(array $data): array
    {
        $stmt = $this->db->prepare("
            INSERT INTO recipes (title, description, ingredients, instructions)
            VALUES (:title, :description, :ingredients, :instructions)
        ");
        $stmt->execute([
            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'ingredients' => $data['ingredients'] ?? null,
            'instructions' => $data['instructions'] ?? null
        ]);

        $id = (int)$this->db->lastInsertId();
        return $this->getById($id);
    }

    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare("
            UPDATE recipes
            SET title = :title, description = :description, ingredients = :ingredients, instructions = :instructions
            WHERE id = :id
        ");
        return $stmt->execute([
            'id' => $id,
            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'ingredients' => $data['ingredients'] ?? null,
            'instructions' => $data['instructions'] ?? null
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM recipes WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }

    public function search(string $query): array
    {
        $stmt = $this->db->prepare("SELECT * FROM recipes WHERE title ILIKE :query OR ingredients ILIKE :query");
        $stmt->execute(['query' => "%$query%"]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
