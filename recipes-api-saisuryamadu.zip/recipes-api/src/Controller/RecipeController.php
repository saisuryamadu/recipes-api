<?php

namespace App\Controller;

use App\Service\RecipeService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class RecipeController
{
    private RecipeService $service;

    public function __construct(RecipeService $service)
    {
        $this->service = $service;
    }

    public function list(): JsonResponse
    {
        $recipes = $this->service->listRecipes();
        return new JsonResponse($recipes);
    }

    public function get(int $id): JsonResponse
    {
        $recipe = $this->service->getRecipe($id);
        if (!$recipe) {
            return new JsonResponse(['error' => 'Recipe not found'], 404);
        }
        return new JsonResponse($recipe);
    }

    public function create(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);
        $recipe = $this->service->createRecipe($data);
        return new JsonResponse($recipe, 201);
    }

    public function update(int $id, Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);
        $success = $this->service->updateRecipe($id, $data);

        if (!$success) {
            return new JsonResponse(['error' => 'Update failed'], 400);
        }

        return new JsonResponse(['message' => 'Recipe updated']);
    }

    public function delete(int $id): JsonResponse
    {
        $success = $this->service->deleteRecipe($id);
        if (!$success) {
            return new JsonResponse(['error' => 'Delete failed'], 400);
        }

        return new JsonResponse(['message' => 'Recipe deleted']);
    }

    public function search(Request $request): JsonResponse
    {
        $query = $request->query->get('q', '');
        $results = $this->service->searchRecipes($query);
        return new JsonResponse($results);
    }
}
