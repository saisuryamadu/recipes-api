<?php

namespace App\Controller;

use App\Service\RatingService;

class RatingController
{
    private RatingService $ratingService;

    public function __construct(RatingService $ratingService)
    {
        $this->ratingService = $ratingService;
    }

    public function rate(array $params): void
    {
        $id = (int) $params['id'];
        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['rating']) || $data['rating'] < 1 || $data['rating'] > 5) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid rating. Must be between 1 and 5.']);
            return;
        }

        $this->ratingService->rate($id, $data['rating']);
        echo json_encode(['message' => 'Rating submitted']);
    }
}
