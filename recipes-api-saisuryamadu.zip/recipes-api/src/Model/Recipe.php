public function __construct(array $data)
{
    $this->id = (int) $data['id'];
    $this->title = $data['title'];
    $this->description = $data['description'] ?? null;
    $this->ingredients = $data['ingredients'] ?? null;
    $this->instructions = $data['instructions'] ?? null;
    $this->created_at = $data['created_at'];
}
public function toArray(): array
{
    return [
        'id' => $this->id,
        'title' => $this->title,
        'description' => $this->description,
        'ingredients' => $this->ingredients,
        'instructions' => $this->instructions,
        'created_at' => $this->created_at
    ];
}
