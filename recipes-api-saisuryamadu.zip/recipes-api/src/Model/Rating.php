<?php

namespace App\Model;

class Rating
{
    public int $recipeId;
    public int $score;

    public function __construct(array $data)
    {
        $this->recipeId = $data['recipe_id'];
        $this->score = $data['score'];
    }

    public function toArray(): array
    {
        return [
            'recipe_id' => $this->recipeId,
            'score' => $this->score
        ];
    }
}
