<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Controller\RecipeController;
use App\Controller\RatingController;
use App\Repository\RecipeRepository;
use App\Repository\RatingRepository;
use App\Routing\Router;
use App\Service\RecipeService;
use App\Service\RatingService;

// Load environment variables from .env
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

// Create PDO database connection
$host = $_ENV['DB_HOST'];
$port = $_ENV['DB_PORT'];
$dbname = $_ENV['DB_NAME'];
$user = $_ENV['DB_USER'];
$pass = $_ENV['DB_PASS'];

$dsn = "pgsql:host=$host;port=$port;dbname=$dbname";
$pdo = new PDO($dsn, $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Set up repositories
$recipeRepo = new RecipeRepository($pdo);
$ratingRepo = new RatingRepository($pdo);

// Set up services
$recipeService = new RecipeService($recipeRepo);
$ratingService = new RatingService($ratingRepo);

// Set up controllers
$recipeController = new RecipeController($recipeService);
$ratingController = new RatingController($ratingService);

// Set up router and routes
$router = new Router();

$router->add('GET', '/recipes', [$recipeController, 'list']);
$router->add('GET', '/recipes/{id}', [$recipeController, 'get']);
$router->add('POST', '/recipes', [$recipeController, 'create'], true);
$router->add('PUT', '/recipes/{id}', [$recipeController, 'update'], true);
$router->add('PATCH', '/recipes/{id}', [$recipeController, 'update'], true);
$router->add('DELETE', '/recipes/{id}', [$recipeController, 'delete'], true);
$router->add('POST', '/recipes/{id}/rating', [$ratingController, 'rate']);
$router->add('GET', '/search', [$recipeController, 'search']);

return $router;
