<?php

namespace App\Routing;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;

class Router
{
    private array $routes = [];

    public function add(string $method, string $path, array $handler, bool $auth = false): void
    {
        $this->routes[] = compact('method', 'path', 'handler', 'auth');
    }

    public function dispatch(): void
    {
        $request = Request::createFromGlobals();
        $path = $request->getPathInfo();
        $method = $request->getMethod();

        foreach ($this->routes as $route) {
            $pattern = preg_replace('#\{[^/]+\}#', '([^/]+)', $route['path']);
            $pattern = "#^" . $pattern . "$#";

            if ($method === $route['method'] && preg_match($pattern, $path, $matches)) {
                array_shift($matches); // remove full match
                $handler = $route['handler'];

                // Call the handler directly — controller is already an object
                $response = call_user_func_array($handler, array_merge([$request], $matches));

                if (!$response instanceof Response) {
                    $response = new JsonResponse($response);
                }

                $response->send();
                return;
            }
        }

        (new JsonResponse(['error' => 'Route not found'], 404))->send();
    }
}