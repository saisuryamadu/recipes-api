<?php

use App\Controller\RecipeController;
use App\Controller\RatingController;
use App\Repository\RecipeRepository;
use App\Repository\RatingRepository;
use App\Service\RecipeService;
use App\Service\RatingService;
use App\Middleware\AuthMiddleware;
use Symfony\Component\DependencyInjection\Reference;

$container->register(RecipeRepository::class)
    ->addArgument(new Reference('db'));

$container->register(RatingRepository::class)
    ->addArgument(new Reference('db'));

$container->register(RecipeService::class)
    ->addArgument(new Reference(RecipeRepository::class));

$container->register(RatingService::class)
    ->addArgument(new Reference(RatingRepository::class));

$container->register(RecipeController::class)
    ->addArgument(new Reference(RecipeService::class));

$container->register(RatingController::class)
    ->addArgument(new Reference(RatingService::class));

$container->register(AuthMiddleware::class);
