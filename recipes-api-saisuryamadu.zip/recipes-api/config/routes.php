<?php

return [
    ['GET',    '/recipes',                   ['App\Controller\RecipeController', 'list']],
    ['POST',   '/recipes',                   ['App\Controller\RecipeController', 'create'], true],
    ['GET',    '/recipes/search',            ['App\Controller\RecipeController', 'search']],
    ['GET',    '/recipes/{id}',              ['App\Controller\RecipeController', 'get']],
    ['PUT',    '/recipes/{id}',              ['App\Controller\RecipeController', 'update'], true],
    ['PATCH',  '/recipes/{id}',              ['App\Controller\RecipeController', 'update'], true],
    ['DELETE', '/recipes/{id}',              ['App\Controller\RecipeController', 'delete'], true],
    ['POST',   '/recipes/{id}/rating',       ['App\Controller\RatingController', 'rate']],
];
