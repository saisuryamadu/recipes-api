<?php

use PHPUnit\Framework\TestCase;
use App\Service\CacheService;

class CacheServiceTest extends TestCase
{
    public function testSetAndGet()
    {
        $cache = new CacheService();
        $cache->set('test-key', 'test-value', 10);
        $this->assertEquals('test-value', $cache->get('test-key'));
    }
}
