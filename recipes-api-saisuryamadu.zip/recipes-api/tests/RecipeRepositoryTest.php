<?php

use PHPUnit\Framework\TestCase;
use App\Repository\RecipeRepository;

class RecipeRepositoryTest extends TestCase
{
    private PDO $pdo;
    private RecipeRepository $repository;

    protected function setUp(): void
    {
        $this->pdo = new PDO('sqlite::memory:');
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->exec("
            CREATE TABLE recipes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                prep_time INTEGER,
                difficulty INTEGER,
                vegetarian BOOLEAN
            );
        ");

        $this->repository = new RecipeRepository($this->pdo);
    }

    public function testCreateAndGet(): void
    {
        $data = [
            'name' => 'Lasagna',
            'prep_time' => 45,
            'difficulty' => 3,
            'vegetarian' => true
        ];

        $created = $this->repository->create($data);
        $fetched = $this->repository->getById($created['id']);

        $this->assertEquals('Lasagna', $fetched['name']);
        $this->assertEquals(45, $fetched['prep_time']);
    }

    public function testUpdate(): void
    {
        $created = $this->repository->create([
            'name' => 'Soup', 'prep_time' => 15, 'difficulty' => 1, 'vegetarian' => true
        ]);

        $updated = $this->repository->update($created['id'], ['name' => 'Tomato Soup']);
        $this->assertTrue($updated);

        $fetched = $this->repository->getById($created['id']);
        $this->assertEquals('Tomato Soup', $fetched['name']);
    }

    public function testDelete(): void
    {
        $created = $this->repository->create([
            'name' => 'Cake', 'prep_time' => 60, 'difficulty' => 2, 'vegetarian' => false
        ]);

        $deleted = $this->repository->delete($created['id']);
        $this->assertTrue($deleted);

        $this->assertNull($this->repository->getById($created['id']));
    }

    public function testSearch(): void
    {
        $this->repository->create(['name' => 'Chili', 'prep_time' => 30, 'difficulty' => 2, 'vegetarian' => false]);
        $results = $this->repository->search('chili');

        $this->assertCount(1, $results);
        $this->assertEquals('Chili', $results[0]['name']);
    }
}
