<?php

use PHPUnit\Framework\TestCase;
use App\Service\RecipeService;
use App\Repository\RecipeRepository;

class RecipeServiceTest extends TestCase
{
    private RecipeRepository $repository;
    private RecipeService $service;

    protected function setUp(): void
    {
        $this->repository = $this->createMock(RecipeRepository::class);
        $this->service = new RecipeService($this->repository);
    }

    public function testListRecipes(): void
    {
        $expected = [['id' => 1, 'name' => 'Pasta']];
        $this->repository->method('getAll')->willReturn($expected);

        $this->assertSame($expected, $this->service->listRecipes());
    }

    public function testGetRecipe(): void
    {
        $expected = ['id' => 1, 'name' => 'Pizza'];
        $this->repository->method('getById')->with(1)->willReturn($expected);

        $this->assertSame($expected, $this->service->getRecipe(1));
    }

    public function testCreateRecipe(): void
    {
        $data = ['name' => 'Burger'];
        $created = ['id' => 10] + $data;

        $this->repository->method('create')->with($data)->willReturn($created);
        $this->assertSame($created, $this->service->createRecipe($data));
    }

    public function testUpdateRecipe(): void
    {
        $this->repository->method('update')->with(1, ['name' => 'Soup'])->willReturn(true);
        $this->assertTrue($this->service->updateRecipe(1, ['name' => 'Soup']));
    }

    public function testDeleteRecipe(): void
    {
        $this->repository->method('delete')->with(1)->willReturn(true);
        $this->assertTrue($this->service->deleteRecipe(1));
    }

    public function testSearchRecipes(): void
    {
        $this->repository->method('search')->with('pasta')->willReturn([['name' => 'pasta']]);
        $this->assertCount(1, $this->service->searchRecipes('pasta'));
    }
}
