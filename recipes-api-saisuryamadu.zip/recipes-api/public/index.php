<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use App\Routing\Router;
use Dotenv\Dotenv;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

// Bootstrap the app (this returns a Router instance)
$router = require __DIR__ . '/../src/bootstrap.php';

// Dispatch the HTTP request
$router->dispatch();
